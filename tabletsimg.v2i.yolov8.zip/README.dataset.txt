# tabletsimg > 2024-10-10 4:01am
https://universe.roboflow.com/proj-4sauf/tabletsimg-cnm41

Provided by a Roboflow user
License: CC BY 4.0

